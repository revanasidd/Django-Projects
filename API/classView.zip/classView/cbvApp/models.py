from django.db import models

# Create your models here.
class UserContact(models.Model):
    id=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=20)
    phone_number = models.IntegerField(unique=True)
    email = models.EmailField()
    
    def __str__(self):
        return self.name
